import { useState, useEffect, useMemo } from 'react';
import { INITIAL_STARTUPS, Startup } from './types';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import DashboardView from './components/DashboardView';
import ProfileView from './components/ProfileView';
import ActiveRaisesView from './components/ActiveRaisesView';
import AdminDirectoryView from './components/AdminDirectoryView';

export default function App() {
  // Core Startups State (persisted in localStorage)
  const [startups, setStartups] = useState<Startup[]>(() => {
    const saved = localStorage.getItem('terminal_vc_startups');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved startups ledger. Reverting to seed data.', e);
      }
    }
    return INITIAL_STARTUPS;
  });

  // Navigation state: 'dashboard' | 'active-raises' | 'admin-directory' | 'profile-[startupId]'
  const [currentView, setView] = useState<string>('dashboard');

  // Currently selected/active startup profile
  const [selectedStartup, setSelectedStartup] = useState<Startup>(() => {
    return startups.find((s) => s.id === 'SOL-1200-A') || startups[0];
  });

  // Global Search Query
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Bookmarked / Starred Favorites (Initial lists match mockup images)
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('terminal_vc_favorites');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback default favorited startups
      }
    }
    return ['SOL-1200-A', 'SOL-4401-K']; // Lumina Protocol, Solayer
  });

  // Telemetry simulation states
  const [tps, setTps] = useState<number>(2401);
  const [footerUtcTime, setFooterUtcTime] = useState<string>('TIME: 14:32:01 UTC');

  // Toast state and handler for elegant, in-app notifications
  const [toast, setToast] = useState<{ message: string; type?: 'info' | 'error' | 'success' } | null>(null);

  const showToast = (message: string, type: 'info' | 'error' | 'success' = 'info') => {
    setToast({ message, type });
  };

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3500);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Sync state changes to localStorage
  useEffect(() => {
    localStorage.setItem('terminal_vc_startups', JSON.stringify(startups));
  }, [startups]);

  useEffect(() => {
    localStorage.setItem('terminal_vc_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Telemetry ticker loop
  useEffect(() => {
    const ticker = setInterval(() => {
      // Oscillate Solana Mainnet TPS around ~2,400 with logical limits
      setTps(Math.floor(2310 + Math.random() * 190));
      
      // Update dynamic UTC clock
      const d = new Date();
      const pad = (n: number) => n.toString().padStart(2, '0');
      setFooterUtcTime(`TIME: ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())} UTC`);
    }, 1000);

    return () => clearInterval(ticker);
  }, []);

  // Helper map for Sidebar favorites resolution
  const startupNamesMap = useMemo(() => {
    return startups.reduce((acc, curr) => {
      acc[curr.id] = curr.name;
      return acc;
    }, {} as Record<string, string>);
  }, [startups]);

  // CRUD & Interaction Callbacks
  const handleSimulatedInvestment = (id: string, amount: number) => {
    setStartups((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          const updatedRaised = s.raised + amount;
          const updatedStartup = { ...s, raised: updatedRaised };
          
          // Keep active view ref in sync
          if (selectedStartup.id === id) {
            setSelectedStartup(updatedStartup);
          }
          return updatedStartup;
        }
        return s;
      })
    );
  };

  const handleCreateStartup = (newStartup: Startup) => {
    setStartups((prev) => [newStartup, ...prev]);
  };

  const handleDeleteStartup = (id: string) => {
    setStartups((prev) => prev.filter((s) => s.id !== id));
    setFavorites((prev) => prev.filter((favId) => favId !== id));
  };

  const handleToggleStatus = (id: string) => {
    setStartups((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          const nextStatus = s.status === 'published' ? 'draft' : s.status === 'draft' ? 'archived' : 'published';
          const updated = { ...s, status: nextStatus as 'published' | 'draft' | 'archived' };
          if (selectedStartup.id === id) {
            setSelectedStartup(updated);
          }
          return updated;
        }
        return s;
      })
    );
  };

  const handleToggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((favId) => favId !== id) : [...prev, id]
    );
  };

  // Switch navigation callback on global search
  useEffect(() => {
    if (searchQuery.trim() !== '' && currentView === 'dashboard') {
      setView('active-raises');
    }
  }, [searchQuery, currentView]);

  return (
    <div className="flex h-screen overflow-hidden bg-background text-on-surface select-none font-sans atmosphere-bg relative">
      {/* Background orbs for premium immersive feel */}
      <div className="absolute top-[-20%] left-[20%] w-[600px] h-[600px] bg-primary/5 rounded-full blur-[140px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[10%] right-[-10%] w-[500px] h-[500px] bg-tertiary/5 rounded-full blur-[140px] pointer-events-none z-0"></div>
      
      {/* Side Navigation Rail */}
      <Sidebar
        currentView={currentView}
        setView={setView}
        favorites={favorites}
        onToggleFavorite={handleToggleFavorite}
        startupNamesMap={startupNamesMap}
      />

      {/* Main Content Workspace viewport */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative z-10">
        
        {/* Top Header Controls bar */}
        <Header
          currentView={currentView}
          setView={setView}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          tps={tps}
        />

        {/* Dynamic Route views resolver */}
        <main className="flex-1 overflow-y-auto pb-10 bg-transparent relative flex flex-col">
          {(() => {
            // Check for profile routing (matches profile-[id])
            if (currentView.startsWith('profile-')) {
              const profileId = currentView.split('profile-')[1];
              const resolvedStartup = startups.find((s) => s.id === profileId);
              
              if (resolvedStartup) {
                return (
                  <ProfileView
                    startup={resolvedStartup}
                    setView={setView}
                    onInvest={handleSimulatedInvestment}
                    isFavorite={favorites.includes(resolvedStartup.id)}
                    onToggleFavorite={handleToggleFavorite}
                    showToast={showToast}
                  />
                );
              }
            }

            switch (currentView) {
              case 'dashboard':
                return (
                  <DashboardView
                    startups={startups}
                    setView={setView}
                    onSelectStartup={setSelectedStartup}
                    showToast={showToast}
                  />
                );
              case 'active-raises':
                return (
                  <ActiveRaisesView
                    startups={startups}
                    setView={setView}
                    onSelectStartup={setSelectedStartup}
                    showToast={showToast}
                  />
                );
              case 'admin-directory':
                return (
                  <AdminDirectoryView
                    startups={startups}
                    setView={setView}
                    onSelectStartup={setSelectedStartup}
                    onCreateStartup={handleCreateStartup}
                    onDeleteStartup={handleDeleteStartup}
                    onToggleStatus={handleToggleStatus}
                    showToast={showToast}
                  />
                );
              default:
                return (
                  <DashboardView
                    startups={startups}
                    setView={setView}
                    onSelectStartup={setSelectedStartup}
                    showToast={showToast}
                  />
                );
            }
          })()}
        </main>

        {/* Global Footer Meta summary bar */}
        <footer className="mt-auto py-1 px-4 border-t border-outline-variant bg-surface-container-lowest/80 backdrop-blur-md flex justify-between items-center text-[9px] font-mono text-on-surface-variant/70 uppercase tracking-widest h-6 z-25 absolute bottom-0 left-0 right-0 select-none">
          <div className="flex items-center space-x-6">
            <span>© 2026 TERMINAL CORP</span>
            <span className="flex items-center">
              <span className="w-1 h-1 bg-primary rounded-full mr-1.5 animate-pulse-slow"></span>
              SYSTEM SECURE
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <span>{footerUtcTime}</span>
            <span>SESSION: SOL-X992</span>
          </div>
        </footer>

      </div>

      {/* Elegant, custom premium toast notification banner */}
      {toast && (
        <div className="fixed bottom-10 right-4 z-50 glass-card px-4 py-3 rounded border border-primary/30 flex items-center space-x-3 shadow-2xl animate-float max-w-sm">
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></div>
          <p className="text-[10px] font-mono uppercase tracking-widest text-primary font-bold">{toast.message}</p>
        </div>
      )}
    </div>
  );
}
